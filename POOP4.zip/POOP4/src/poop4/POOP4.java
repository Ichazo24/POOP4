/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package poop4;

/**
 *
 * @author Kikin
 */
public class POOP4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Punto punto = new Punto();
        punto.x = 5;
        punto.y = 9;
        punto.imprimePunto();
        System.out.println("###############################");
        
        Punto punto2 =new Punto();
        punto2.x =10;
        punto2.y =3;
        punto2.imprimePunto();
        System.out.println("##############################");
        
        Punto punto3 = new Punto(15,3);
        punto3.imprimePunto();
        System.out.println("###############################");
        
        Triangulo triangulo1 = new Triangulo();
        triangulo1.base=5;
        triangulo1.altura=8;
        System.out.println("la base = "+triangulo1.base);
        System.out.println("la altura = "+triangulo1.altura);
        System.out.println("perimetro = "+ triangulo1.perimetro());
        System.out.println("area = "+triangulo1.area());
        System.out.println("##############################");
        
        Triangulo triangulo2 =new Triangulo(2.0f,2.0f);
        System.out.println("la base = "+triangulo2.base);
        System.out.println("la altura = "+triangulo2.altura);
        System.out.println("perimetro = "+ triangulo2.perimetro());
        System.out.println("area = "+triangulo2.area());
        System.out.println("##############################");
        
        Perro perro1 = new Perro ();
        perro1.color= "Negro";
        perro1.raza = "Labrador";
        perro1.nombre = "Kaia";
        perro1.edad = 5;
        perro1.peso = (float)20.15;
        perro1.croquetas = "Comiendo croquetas Royal canine";
        perro1.imprimePerro();
        perro1.caminar();
        perro1.ladrar();
        perro1.comer();
        perro1.correr();
        System.out.println("##############################");
        
        Coche coche1 = new Coche();
        coche1.color = "Rojo";
        coche1.marca = "Tesla";
        coche1.modelo = 2021 ;
        coche1.numPuertas = 2;
        coche1.placa = "ICZ-24-25";
        coche1.prender();
        coche1.apagar();
        coche1.frenar();
        coche1.girar("girando");
        coche1.prender();
        System.out.println("#############################");
        
    }
}


   
