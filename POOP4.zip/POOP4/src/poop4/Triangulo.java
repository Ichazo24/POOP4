/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poop4;

/**
 *
 * @author Kikin
 */
public class Triangulo {
    
float base, altura;

    public Triangulo() {
    }

    public Triangulo(float base, float altura) {
        this.base = base;
        this.altura = altura;
    }
    
    public float area(){
        return (float) base*altura/2;
    }
    
    public float perimetro(){
        return (float) base*3;
    }
    
}
