/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poop4;

/**
 *
 * @author Kikin
 */
public class Perro {
    String color, raza, nombre, croquetas;
    int edad;
    float peso;

    public Perro() {
    }

    public Perro(String color, String tamaño, String raza, String nombre, int edad, float peso) {
        this.color = color;
        this.raza = raza;
        this.nombre = nombre;
        this.edad = edad;
        this.peso = peso;
    }
    
    public Perro(String color, String tamaño, String raza, String nombre, int edad, float peso, String croquetas) {
        this.color = color;
        this.raza = raza;
        this.nombre = nombre;
        this.edad = edad;
        this.peso = peso;
        this.croquetas = croquetas;
    }
    
    public void imprimePerro(){
        System.out.println(" color ->" +color+"/"+ "raza ->"+raza+ "/"+" nombre ->"+nombre+"/"+ "edad ->"+edad+"/"+ "peso ->"+peso);
    }
    
    public void caminar(){
        System.out.println("caminando");
    }
    
    public void ladrar(){
        System.out.println("ladrando");
    }
   
    public void comer(){
        System.out.println("come");
    }
    
    public String Comer(String croquetas){
        return (String) "terminando de comer";
    }
    
    public void correr(){
        System.out.println("corriendo");
    }
}
