/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poop4;

/**
 *
 * @author Kikin
 */
public class Coche {

String marca, color, placa, direccion ="derecha o izquierda";
int modelo, numPuertas;

public Coche(){
}

public Coche(String marca, String color, String placa, int modelo, int numPuertas) {
this.marca = marca;
this.color = color;
this.placa = placa;
this.modelo = modelo;
this.numPuertas = numPuertas;
}

public void prender(){
    System.out.println("Prendiendo"); 
}

public void apagar(){
    System.out.println("Apagando"); 
}

public void frenar(){
    System.out.println("Frenando");
}

public String girar(String girando){
return (String) direccion; 
}

public void acelerar(){    
    System.out.println("Acelerando");
}

}
